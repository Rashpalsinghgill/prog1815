﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Data_Shown
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                StreamWriter write = new StreamWriter("show.txt", true);

                string p = textBox2.Text;
                string q = textBox3.Text;
                string r = textBox4.Text;
                string s = textBox5.Text;
                string t = textBox6.Text;
                string u = textBox7.Text;
                string v = textBox8.Text;

                write.WriteLine(p + "  ," + q + "   ," + r + "   ," + s + "  ," + t + "  ," + u + "   ," + v);
                write.Close();
                MessageBox.Show("Data send");
            }

            else if (radioButton2.Checked)
            {
                String myFile;
                OpenFileDialog save = new OpenFileDialog();
                save.InitialDirectory = Directory.GetCurrentDirectory();

                if (save.ShowDialog() == DialogResult.OK)
                {
                    myFile = save.FileName;
                    label11.Text = "";
                    StreamReader writ = new StreamReader(myFile);
                    while(writ.EndOfStream==false)
                    {
                        label11.Text = label11.Text + "   " + writ.ReadLine();
                    }
                    writ.Close();
                }
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string del = ",";
            string t_name = "Table";
            DataSet disp = new DataSet();
            OpenFileDialog kil = new OpenFileDialog();
            kil.Filter = "ALL Files(*.*)|*.*";
            kil.FilterIndex = 1;
            if (kil.ShowDialog() == DialogResult.OK)
            {
                string f_name = kil.FileName;
                StreamReader obj = new StreamReader(f_name);
                string data = File.ReadAllText(kil.FileName);
                disp.Tables.Add(t_name);
                disp.Tables[t_name].Columns.Add("#");
                disp.Tables[t_name].Columns.Add("Purchase-Data");
                disp.Tables[t_name].Columns.Add("Serial #");
                disp.Tables[t_name].Columns.Add("Manufacturing Tools");
                disp.Tables[t_name].Columns.Add("Price");
                disp.Tables[t_name].Columns.Add("Qty");
                disp.Tables[t_name].Columns.Add("Amount");

                string all = obj.ReadToEnd();
                string[] rows = all.Split("\r".ToCharArray());

                foreach (string r in rows)
                {
                    string[] items = r.Split(del.ToCharArray());
                    disp.Tables[t_name].Rows.Add(items);
                }
                this.dataGridView1.DataSource = disp.Tables[0].DefaultView;
            }
            else
            {
                this.Close();
            }
        }
    }
}
